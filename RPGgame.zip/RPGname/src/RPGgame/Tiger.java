package RPGgame;

import javax.swing.ImageIcon;

class Tiger extends Animals{
	public Tiger(){
		super("�ϻ�", 100, 25, 25);
		// TODO Auto-generated constructor stub
		this.image = new ImageIcon("Images/Tiger.JPG");
	}
}