package RPGgame;

import javax.swing.ImageIcon;

public class Eagle extends Animals {
	public Eagle(){
		super("ӥ",100, 45, 20);
		// TODO Auto-generated constructor stub
		this.image = new ImageIcon("Images/Eagle.JPG");
	}
}
