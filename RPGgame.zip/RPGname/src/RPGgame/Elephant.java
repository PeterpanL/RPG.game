package RPGgame;

import javax.swing.ImageIcon;

public class Elephant extends Animals {
	public Elephant(){
		super("����",100, 25, 35);
		// TODO Auto-generated constructor stub
		this.image = new ImageIcon("Images/Elephant.JPG");
}
}