package RPGgame;

import javax.swing.ImageIcon;

public class Whale extends Animals {
	public Whale(){
		super("��",100, 35, 50);
		// TODO Auto-generated constructor stub
		this.image = new ImageIcon("Images/Whale.JPG");
	}
}
