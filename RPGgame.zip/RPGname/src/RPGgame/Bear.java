package RPGgame;

import javax.swing.ImageIcon;

class Bear extends Animals{
	public Bear(){
		super("��",100, 15, 30);
		// TODO Auto-generated constructor stub
		this.image = new ImageIcon("Images/Bear.JPG");
	}
}