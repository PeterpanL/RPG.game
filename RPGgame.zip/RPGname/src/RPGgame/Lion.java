package RPGgame;

import javax.swing.ImageIcon;

class Lion extends Animals{
	public Lion(){
		super("ʨ��",100, 30, 15);
		// TODO Auto-generated constructor stub
		this.image = new ImageIcon("Images/Lion.JPG");
	}
}